
var num=1;
alert("hii"+num);

function add(){
    var data = '<form id="FORM-'+window.num+'" class="add" style="margin-top: 10px;">\
    <select class="category" placeholder="Year"><option selected>Year</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option></select>\
    <select class="category"><option selected>Semester</option><option>A</option><option>B</option><option>S</option></select>\
    <input class="category" type="text" name="name_course" placeholder="Name course">\
    <input class="category" id="credits"  type="number" name="credits" placeholder="Credits">\
    <input class="category" id="grade" type="number" name="final grade" placeholder="Final grade">\
    <label class="category"><p id="average" style="font-weight: 600; font-size: 25px;"></p></label>\
    <button class="category" onclick="del(this); return false;" id="delete-'+window.num+'" style="width: 5%;"><i class="fa fa-trash"></i></button>\ </form>'

    var newContent = document.createElement("div");
    newContent.innerHTML = data;
    document.getElementById('target').appendChild(newContent);
    num++;
    alert("add"+num);

}

function del(elem) {
    var data = '<form id="FORM-'+window.num+'" class="add" style="margin-top: 10px;">\
    <select class="category" placeholder="Year"><option selected>Year</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option></select>\
    <select class="category"><option selected>Semester</option><option>A</option><option>B</option><option>S</option></select>\
    <input class="category" type="text" name="name_course" placeholder="Name course">\
    <input class="category" id="credits"  type="number" name="credits" placeholder="Credits">\
    <input class="category" id="grade" type="number" name="final grade" placeholder="Final grade">\
    <label class="category"><p id="average" style="font-weight: 600; font-size: 25px;"></p></label>\
    <button class="category" onclick="del(this); return false;" id="delete-'+window.num+'" style="width: 5%;"><i class="fa fa-trash"></i></button>\ </form>'

    var clicked = elem.form.getAttribute('id');
    var jjjj = elem.getAttribute('id');

    var element_form = document.getElementById(clicked);

    element_form.remove();
    alert("ID FORM: "+ clicked + "deleted!!!!\nID BUTTON: "+jjjj+"deleted!!!");
    num--;

    alert(num);
}

function login() {
    window.location.assign("loginPage.html")
};

function home() {
    window.location.assign("index.html")
};

function about() {
    window.location.assign("aboutPage.html")
};

function main() {
    window.location.assign("main.html");
}


function signUp() {
    //const auth = firebase.auth();
    let id= 1;
    var user_email = document.getElementById("user_email").value;
    var user_psw = document.getElementById("user_psw").value;
    var user_name = document.getElementById("user_name").value;	
    firebase.auth().createUserWithEmailAndPassword(user_email, user_psw).then((userCredential) => {
        // Signed up
        var user = userCredential.user;
        const db = firebase.firestore();
        db.collection("Students").doc(user_email).set({
          Name: user_name,
          Email:user_email,
          Password:user_psw,
          id:{Year: "Year",
          Semester: "Semester",
          NameCourse: "",
          Credits: "", 
          Grade: ""}
        }).then((docRef) => {
            console.log("Document written with ID: ", docRef);
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });
        id++;
    })
    .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(error.message);

        // ..
    });
};


function signIn() { 
    //const auth = firebase.auth();
    var user_email = document.getElementById("login_email").value;
    var user_psw = document.getElementById("login_psw").value;
    const myObjectString = JSON.stringify(user_email);
    localStorage.setItem('objectGreeting', myObjectString);
   // var user_name = document.getElementById("user_name").value;
    var db = firebase.firestore();
	
    firebase.auth().signInWithEmailAndPassword(user_email, user_psw).then(async (userCredential) => {
        // Signed up
        var user = userCredential.user;
        window.location.assign("main.html");

    })
    .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(error.message);

        // ..
    });

};


function gal(){
    alert("shhh");
    const myObjectString2 = localStorage.getItem('objectGreeting');
    const myObject2 = JSON.parse(myObjectString2);
    var db = firebase.firestore();
    var docRef = db.collection("Students").doc(myObject2);
    return docRef.update({
    id:{Year: document.getElementById("year").value,
    Semester:document.getElementById("semester").value,
    NameCourse:document.getElementById("name_course").value,
    Credits:document.getElementById("credits").value, 
    Grade: document.getElementById("grade").value}
    })
    .then(() => {
        console.log("Document successfully updated!");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });
    
};

function save() {
    const myObjectString2 = localStorage.getItem('objectGreeting');
    const myObject2 = JSON.parse(myObjectString2);
    var db = firebase.firestore();
    var docRef = db.collection("Students").doc(myObject2);
    return docRef.update({
    idd:{Year: document.getElementById("year").value,
    Semester:document.getElementById("semester").value,
    NameCourse:document.getElementById("name_course").value,
    Credits:document.getElementById("credits").value, 
    Grade: document.getElementById("grade").value}
    })
      .then((docRef) => {
          console.log("Document written with ID: ", docRef);
      })
      .catch((error) => {
          console.error("Error adding document: ", error);
      });
};

